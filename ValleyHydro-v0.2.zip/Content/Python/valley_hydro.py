"""Editor-only gameplay for Lvl_ValleyHydro. Loaded by Content/Python/init_unreal.py."""
import math
import unreal as u

MAP = "Lvl_ValleyHydro"
START = (460, -510, 710)
CHECKPOINT = (2680, -350, 108)
BRANCHES = {"A": (6530, -300), "B": (6530, 410)}
TAGS = ("west_gate", "east_gate", "exit_gate", "lift", "power_beacon", "steam_beacon")
editor = u.get_editor_subsystem(u.UnrealEditorSubsystem)
levels = u.get_editor_subsystem(u.LevelEditorSubsystem)

def input_key(name):
    key = u.Key()
    key.import_text(f"(KeyName={name})")
    return key

INTERACT = input_key("E")
RESTART = input_key("R")


def near(pos, x, y, z, radius=240):
    return math.hypot(pos.x-x, pos.y-y) <= radius and abs(pos.z-z) <= 160


def teleport(pc, pawn, xyz):
    rotation = u.Rotator(yaw=13)
    pawn.get_movement_component().stop_movement_immediately()
    pawn.set_actor_location_and_rotation(u.Vector(*xyz), rotation, False, True)
    pc.set_control_rotation(rotation)


class Session:
    def __init__(self, world, now):
        self.world = world
        self.objects = {}
        for tag in TAGS:
            matches = u.GameplayStatics.get_all_actors_with_tag(world, "hydro_" + tag)
            if len(matches) != 1:
                raise RuntimeError(f"Expected one actor tagged hydro_{tag}, found {len(matches)}.")
            self.objects[tag] = matches[0]
        self.origins = {name: actor.get_actor_location() for name, actor in self.objects.items()}
        guides = u.GameplayStatics.get_all_actors_with_tag(world, "hydro_guide")
        markers = u.GameplayStatics.get_all_actors_with_tag(world, "hydro_guide_marker")
        self.guides = sorted(guides, key=lambda actor: -actor.get_actor_location().x)
        self.markers = sorted(markers, key=lambda actor: -actor.get_actor_location().x)
        self.restart(now)

    def restart(self, now):
        self.phase = "BLACKOUT"
        self.lift_started = None
        self.lift_bottom = False
        self.started = now
        self.powered_at = None
        self.guide_count = 0
        self.notice = ""
        self.notice_until = 0
        for name in ("west_gate", "east_gate", "exit_gate", "lift"):
            self.objects[name].set_actor_location(self.origins[name], False, True)
        self.light("power_beacon", 0)
        for light in self.guides:
            light.point_light_component.set_intensity(0)
        for marker in self.markers:
            marker.set_actor_hidden_in_game(True)

    def light(self, name, intensity):
        self.objects[name].point_light_component.set_intensity(intensity)

    def raise_gate(self, name):
        point = self.origins[name]
        self.objects[name].set_actor_location(u.Vector(point.x,point.y,point.z+430),False,True)

    def update_guides(self, now):
        if self.powered_at is None:
            return
        count = min(len(self.guides), 1 + int((now-self.powered_at)/0.24))
        for index in range(self.guide_count, count):
            self.guides[index].point_light_component.set_intensity(36000)
            self.markers[index].set_actor_hidden_in_game(False)
        self.guide_count = count

    def hint(self, pos, steam, branch):
        if self.phase == "COMPLETE":
            return "Maintenance exit reached  |  R: restart"
        if self.phase == "EXIT OPEN":
            return "Walk through the open gate."
        if self.phase == "POWERED":
            if not self.lift_bottom and near(pos,4340,1450,708,165):
                return "E: ride the lift down"
            if self.lift_bottom and near(pos,7080,2440,108,290):
                return "E: open the maintenance exit"
            return "Follow the green markers to the return gantry and lift."
        if branch:
            return f"E: connect branch {branch}  |  Check the header pressure."
        if near(pos,850,760,708,280):
            return "E: check the maintenance gate"
        if 2560 < pos.x < 4230 and pos.z < 400:
            return "STEAM ACTIVE  |  wait for the light to go out" if steam else "STEAM CLEAR  |  cross the orange strip"
        return "Reach CONTROL. Choose UPPER WALKWAY or LOWER / STEAM."

    def step(self, pc, pawn, now, interact):
        pos = pawn.get_actor_location()
        branch = next((name for name, (x, y) in BRANCHES.items()
                       if near(pos,x,y,708,265)), None)
        self.update_guides(now)
        steam = ((now-self.started) % 8) < 2.6
        self.light("steam_beacon", 23000 if steam else 0)
        if steam and 3200 < pos.x < 3860 and -765 < pos.y < 65 and pos.z < 365:
            teleport(pc,pawn,CHECKPOINT)
            self.notice = "Steam hit. Restarted before the hazard."
            self.notice_until = now + 2
            return self.notice
        if self.lift_started is not None:
            progress = min(1, (now-self.lift_started)/3)
            self.objects["lift"].set_actor_location(u.Vector(4340,1450,577.5-600*progress),False,True)
            pawn.get_movement_component().stop_movement_immediately()
            pawn.set_actor_location(u.Vector(4340,1450,708-600*progress),False,True)
            if progress < 1:
                return "Lift descending"
            self.lift_started = None
            self.lift_bottom = True
            return "Follow the lower maintenance corridor to the exit."
        if interact:
            if self.phase == "BLACKOUT" and branch == "A":
                self.notice = "A still venting. Pressure unstable. Try another branch."
                self.notice_until = now + 3
            elif self.phase == "BLACKOUT" and branch == "B":
                self.phase = "POWERED"
                self.powered_at = now
                self.notice = "B connected. Follow the green markers to the lift."
                self.notice_until = now + 2
                self.raise_gate("west_gate")
                self.raise_gate("east_gate")
                self.light("power_beacon", 38000)
                self.update_guides(now)
            elif self.phase == "BLACKOUT" and near(pos,850,760,708,280):
                self.notice = "Maintenance gate has no power. Reach CONTROL."
                self.notice_until = now + 3
            elif self.phase == "POWERED" and not self.lift_bottom and near(pos,4340,1450,708,165):
                self.lift_started = now
            elif self.phase == "POWERED" and self.lift_bottom and near(pos,7080,2440,108,290):
                self.phase = "EXIT OPEN"
                self.raise_gate("exit_gate")
        if self.phase == "EXIT OPEN" and pos.x > 7410 and 1990 < pos.y < 2450 and pos.z < 300:
            self.phase = "COMPLETE"
            self.elapsed = now - self.started
        return self.notice if self.notice_until > now else self.hint(pos, steam, branch)


session = None
keys_held = (False, False)

def tick(_delta):
    global session, keys_held
    if not levels.is_in_play_in_editor():
        session = None
        keys_held = (False, False)
        return
    world = editor.get_game_world()
    if not world or world.get_name() != MAP:
        return
    pc = u.GameplayStatics.get_player_controller(world, 0)
    pawn = pc.get_controlled_pawn() if pc else None
    if not pawn:
        return
    now = u.GameplayStatics.get_time_seconds(world)
    if session is None or session.world != world:
        session = Session(world,now)
    pressed = pc.is_input_key_down(INTERACT), pc.is_input_key_down(RESTART)
    interact, restart = (current and not held for current, held in zip(pressed, keys_held))
    keys_held = pressed
    if restart:
        session.restart(now)
        teleport(pc,pawn,START)
    message = session.step(pc,pawn,now,interact)
    heading = f"COMPLETE  /  {session.elapsed:.1f}s" if session.phase == "COMPLETE" else session.phase
    u.SystemLibrary.print_string(world, f"{heading}  |  {message}", True, False,
                                 u.LinearColor(.92,.98,1,1), .17, "ValleyHydro")


def guard(delta):
    try:
        tick(delta)
    except Exception:
        u.unregister_slate_post_tick_callback(handle)
        raise


handle = u.register_slate_post_tick_callback(guard)

