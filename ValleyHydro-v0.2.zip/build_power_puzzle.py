import unreal as u

MAP = "/Game/ValleyHydro/Lvl_ValleyHydro"
FOLDER = "09 Power puzzle"
levels = u.get_editor_subsystem(u.LevelEditorSubsystem)
actors = u.get_editor_subsystem(u.EditorActorSubsystem)
assert levels.load_level(MAP)
for actor in actors.get_all_level_actors():
    if str(actor.get_folder_path()) == FOLDER:
        actors.destroy_actor(actor)

cube = u.load_asset("/Engine/BasicShapes/Cube.Cube")
def spawn(cls, label, x, y, z, yaw=0, tag=None):
    actor = actors.spawn_actor_from_class(cls,u.Vector(x,y,z),u.Rotator(yaw=yaw))
    actor.set_actor_label(label)
    actor.set_folder_path(FOLDER)
    if tag:
        actor.set_editor_property("tags",[tag])
        actor.root_component.set_mobility(u.ComponentMobility.MOVABLE)
    return actor

def box(label, x,y,z, width,depth,height, material, collision=False):
    actor=spawn(u.StaticMeshActor,label,x,y,z)
    mesh=actor.static_mesh_component
    mesh.set_static_mesh(cube)
    mesh.set_material(0,u.load_asset(f"/Game/ValleyHydro/Materials/M_{material}"))
    mesh.set_collision_profile_name("BlockAll" if collision else "NoCollision")
    actor.set_actor_scale3d(u.Vector(width/100,depth/100,height/100))

def sign(label, message, x,y,z, size=36, yaw=180, color=(231,244,251), tag=None):
    actor=spawn(u.TextRenderActor,label,x,y,z,yaw,tag)
    text=actor.text_render
    text.set_text(message)
    text.set_world_size(size)
    text.set_horizontal_alignment(u.HorizTextAligment.EHTA_CENTER)
    text.set_text_render_color(u.Color(*color,255))

def light(label, x,y,z,color, intensity, tag=None):
    actor=spawn(u.PointLight,label,x,y,z,tag=tag)
    comp=actor.point_light_component
    comp.set_editor_property("light_color",u.Color(*color,255))
    comp.set_editor_property("intensity",intensity)
    comp.set_editor_property("attenuation_radius",470)

for existing in actors.get_all_level_actors():
    if existing.get_actor_label()=="Power console":
        existing.set_actor_label("Existing podium A")
    elif existing.get_actor_label()=="POWER":
        existing.text_render.set_text("A / CONNECT")

box("Podium B",6530,410,667.5,150,240,135,"B",True)
sign("Console B sign","B / CONNECT",6525,410,780,58)
sign("Control wiring","CONNECT A STABLE BRANCH",6725,40,1130,58)
sign("Control circuit diagram","A : SOUTH HEADER   |   B : NORTH HEADER",6720,40,1030,40)
sign("Upper survey heading","INSPECTION / HEADER STATUS",3170,-1330,915,47)
sign("Upper A sightline","A / SOUTH HEADER",2850,290,1005,76,color=(255,177,109))
sign("Upper A status","VENTING",2850,290,905,64,color=(255,177,109))
sign("Upper B sightline","B / NORTH HEADER",4190,900,1150,76,color=(133,223,255))
sign("Upper B status","STABLE",4190,900,1050,64,color=(133,223,255))
light("A pressure indicator",2840,290,830,(255,99,41),27000)
light("B pressure indicator",4190,900,960,(76,200,248),27000)
sign("Lower inspection board","PRESSURE LOG",2890,-510,315,40)
sign("Lower A status","SOUTH / A : VENTING",2890,-510,251,31,color=(255,177,109))
sign("Lower B status","NORTH / B : STABLE",2890,-510,205,31,color=(133,223,255))
sign("Steam timing cue","CROSS WHEN STEAM LIGHT GOES DARK",3170,-350,320,27)
box("A manifold riser",2860,340,605,86,86,670,"A")
box("A header",4640,340,925,3640,72,72,"A")
box("A drop to panel",6450,340,840,72,72,165,"A")
box("B manifold riser",4190,900,735,86,86,670,"B")
box("B header",5320,900,1055,2310,72,72,"B")
box("B drop to panel",6450,900,915,72,72,280,"B")
sign("Return label near controls","RETURN GANTRY / LIFT",6600,890,965,48,yaw=-90)
for i,(x,y,z,yaw) in enumerate([(6310,1000,835,-90),(6280,1470,835,-90),(5730,1470,835,0),(5300,1470,835,0),(4860,1470,835,0),(4420,1470,835,0)]):
    light(f"Guidance {i+1}",x,y,z,(100,255,122),0,"hydro_guide")
    sign(f"Guidance marker {i+1}","LIFT" if i==5 else "CHEVRON  /  LIFT",x,y,z-38,34,yaw,(161,255,150),"hydro_guide_marker")
assert levels.save_current_level()
u.log("HYDRO_PUZZLE_SAVED")
